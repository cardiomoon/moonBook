predict3 version 0.1.3.3
========================
(2019-Jun-7)

# CalEquation function can calculate intercept in multiple regression model with interaction

predict3 version 0.1.3.2
=======================
(2019-Apr-24)

# New arguments summarymode added to fit2newdata(), predict3d() and ggPredict()


predict3 version 0.1.3.1
=======================
(2019-Apr-11)

# New arguments xlab, ylab and zlab added to predict3d()

predict3 version 0.1.3
=======================
(2019-Apr-3)

# New function gg_color_hue() and theme_bw2() added

predict3d version 0.1.2
=======================
(2019-Mar-11)

# Bug-fixed

# New function restoreData2(), restoreData3()  added


predict3d version 0.1.1
=======================
(2019-Mar-9)

# Bug-fixed

# New function add_lines() added



predict3d version 0.1.0
=======================
(2019-Mar-6)

# New function ggPredict() and predict3d() added

# New function fit2newdata() added


