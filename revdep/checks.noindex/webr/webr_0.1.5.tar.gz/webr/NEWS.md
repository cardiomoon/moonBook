# webr version 0.1.5
====================
(25-Jan-2020)

* Bug-fixed

* CRAN release


# webr version 0.1.4
====================
(12-Mar-2019)

* Bug-fixed


# webr version 0.1.3
====================
(11-Aug-2018)

* new functions for chisqure test added : x2summary(), x2Table()

# webr version 0.1.2
====================
(17-June-2018)

* new function transparent(), gg_color_hue(), makeSubcolor() added

* new function PieDonut() added

# webr version 0.1.1
=====================
(19-May-2018)

* new functions freqTable() and myFreqTable() added

* new functions numSummary() and numSummaryTable() added

* dictionary file dicTable added

* new function langchoice1() added


# webr version 0.1.0
=====================
(18-Apr-2018)

* new function plot.htest() added

* new functions rens.text() and cox.stuart.test() added



