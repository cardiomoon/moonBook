# rrtable version 0.2.1
=======================
(14-Mar-2020)

* new function p2character added

# rrtable version 0.2.0
=======================
(6-Mar-2020)

* new function data2pptx2, data2docx2, image2pptx added 

* new shiny module chooser, chooser2 added

# rrtable version 0.1.9
=======================
(26-Feb-2020)

* bug-fixed



# rrtable version 0.1.8
=======================
(22-Feb-2020)

* bug-fixed

* new function code2office, code2pptx and code2docx added


# rrtable version 0.1.7
=======================
(4-Feb-2020)

* bug-fixed

* The argument 'plottype' added to the functions add_anyplot, plot2pptx and add_2plots

# rrtable version 0.1.6
=======================
(29-Jan-2020)

* new vignette 'update' added


# rrtable version 0.1.5
=======================
(29-Jan-2020)

* new function plot2office, plot2pptx, plot2docx, is_ggplot2, table2office, table2pptx and table2docx added

* new function Rcode2office, Rcode2pptx and Rcode2docx added

# rrtable version 0.1.4
=======================
(27-Jan-2020)

* Modify the code to accommodate changes in the officer package


# rrtable version 0.1.3
=======================
(21-Aug-2018)

* new functions file2HTML(), file2pdf(), file2pptx() and file2word() added for reproducible research

# rrtable version 0.1.2
=======================
(19-Aug-2018)

* bug-fixed 

* shiny module pptxList() can select data with webr::chooserInput()

# rrtable version 0.1.1
=======================
(9-Aug-2018)

* compatible with editData 0.1.5

# rrtable version 0.1.0
=======================
(15-Apr-2018)

* new function add_title(), add_text(), add_2ggplots(), add_2plots added

* new function set_argument() added

* new shiny module pptxList() and pptxListUI() added

* new shiny app(app.R) added in inst/pptxList folder

* new functions data2HTML(), data2pdf(), data2office(), data2pptx() and data2word() added for reproducible research

* new functions df2flextable() and mytable2flextable() added

* new functions readComment(), writeCSVComment(), exportCSV() added


