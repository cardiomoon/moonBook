# ggplotAssist 0.1.3
=====================
(2017-Nov-12)

* bug fixed

* now support labelling geom_bar() or geom_col() 

# ggplotAssist 0.1.2
====================
(2017-Nov-5)

* bug fixed

* now support position_*() functions

# ggplotAssist 0.1.1
====================
(2017-Nov-2)

* new function "uiOutput3","textInput4","textAreaInput4" added

* An recursive shiny module "textFunctionInput" and "textFunction" added

* Two toy shiny apps included in "inst" folder

# ggplotAssist 0.1.0
====================
(2017-Oct-24)

* new function "ggplotAssist" added
